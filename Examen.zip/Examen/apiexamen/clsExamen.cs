﻿using apiexamen.Models;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Net.Http;
using System.Text;
using Newtonsoft.Json;
using System.Net;
using System.Text.RegularExpressions;

namespace apiexamen
{
    public class clsExamen
    {
        public SqlConnection conn = null;
        public SqlCommand comm = null;
        public string Resultado = string.Empty;
        public void getConnection ()
        {
            conn = new SqlConnection("server=EKT5CG4B1ZLAP\\SQLEXPRESS;database=BdiExamen;trusted_connection=true;TrustServerCertificate=True;");
        }
        //el parametro dbinstace al ser True direcionara el request a ADO.net 
        public bool AgregarExamen(int idExamen, string Nombre, string Descripcion, bool dbinstance)
        {
            bool result = false;
            if (!isValidsint(idExamen))
            {
                Resultado = "Validar Valor IdExamen, ";
                return false;
            }    
            if (!isValidstring(Nombre))
            {
                Resultado = "Validar Valor Nombre, ";
                return false;
            }
            if (!isValidstring(Descripcion))
            {
                Resultado = "Validar Valor Descrpcion.";
                return false;
            }
            if (dbinstance)
            {
                try
                {

                    getConnection();
                    comm = new SqlCommand("spAgregar", conn);
                    comm.CommandType = CommandType.StoredProcedure;
                    comm.Parameters.Add("@id", SqlDbType.Int).Value = idExamen;
                    comm.Parameters.Add("@Nombre", SqlDbType.Int).Value = Nombre;
                    comm.Parameters.Add("@Descripcion", SqlDbType.Int).Value = Descripcion;
                    conn.Open();
                    comm.ExecuteNonQuery();
                    conn.Close();
                    Resultado = "Se ejecuto con exito";
                    result = true;

                }
                catch (SqlException sqex)
                {
                    Resultado = sqex.InnerException.ToString();
                    return false;
                }
                finally
                {
                    conn.Close();
                }
            }
            else
            {
                try
                {
                    var Exam = new Examen
                    {
                        idExamen = idExamen,
                        Nombre = Nombre,
                        Descripcion = Descripcion
                    };
                    var client = new HttpClient();
                    client.BaseAddress = new Uri("https://localhost:7251/api/");

                    var json = JsonConvert.SerializeObject(Exam);
                    var content = new StringContent(json, Encoding.UTF8, "application/json");

                    var response = client.PostAsync("Examen", content).Result;

                    if (response.IsSuccessStatusCode)
                    {
                        result = true;

                    }
                    else
                    {
                        result = false;
                    }
                }
                catch (WebException webex)
                {

                }
                finally
                {

                }
            }
            return result;
        }

        
            
        public bool ActualizarExamen(int idExamen, string Nombre, string Descripcion, bool dbinstance)
        {
            if (!isValidsint(idExamen))
            {
                Resultado = "Validar Valor IdExamen, ";
                return false;
            }
            if (!isValidstring(Nombre))
            {
                Resultado = "Validar Valor Nombre, ";
                return false;
            }
            if (!isValidstring(Descripcion))
            {
                Resultado = "Validar Valor Descrpcion.";
                return false;
            }
            bool result = false;
            if (dbinstance)
            {
                try
                {

                    getConnection();
                    comm = new SqlCommand("spActualizar", conn);
                    comm.CommandType = CommandType.StoredProcedure;
                    comm.Parameters.Add("@id", SqlDbType.Int).Value = idExamen;
                    comm.Parameters.Add("@Nombre", SqlDbType.Int).Value = Nombre;
                    comm.Parameters.Add("@Descripcion", SqlDbType.Int).Value = Descripcion;
                    conn.Open();
                    comm.ExecuteNonQuery();
                    conn.Close();
                    Resultado = "Se ejecuto con exito";
                    return true;

                }
                catch (SqlException sqex)
                {
                    Resultado = sqex.InnerException.ToString();
                    return false;
                }
                finally
                {
                    conn.Close();
                }
            }
            else
            {
                try
                {
                    var Exam = new Examen
                    {
                        idExamen = idExamen,
                        Nombre = Nombre,
                        Descripcion = Descripcion
                    };
                    var client = new HttpClient();
                    client.BaseAddress = new Uri("https://localhost:7251/api/");

                    var json = JsonConvert.SerializeObject(Exam);
                    var content = new StringContent(json, Encoding.UTF8, "application/json");

                    var response = client.PutAsync("Examen", content).Result;

                    if (response.IsSuccessStatusCode)
                    {
                        result = true;

                    }
                    else
                    {
                        result = false;
                    }
                }
                catch (WebException webex)
                {

                }
                finally
                {

                }
            }
            return result;
            
        }

        public bool EliminarExamen(int idExamen, bool dbinstance)
        {
            if (!isValidsint(idExamen))
            {
                Resultado = "Validar Valor IdExamen.";
                return false;
            }
            bool result = false;
            if (dbinstance)
            {
                try
                {

                    getConnection();
                    comm = new SqlCommand("spEliminar ", conn);
                    comm.CommandType = CommandType.StoredProcedure;
                    comm.Parameters.Add("@id", SqlDbType.Int).Value = idExamen;
                    conn.Open();
                    comm.ExecuteNonQuery();
                    conn.Close();
                    Resultado = "Se ejecuto con exito";
                    return true;

                }
                catch (SqlException sqex)
                {
                    Resultado = sqex.InnerException.ToString();
                    return false;
                }
                finally
                {
                    conn.Close();
                }
            }
            else
            {
                try
                {
                    var client = new HttpClient();
                    client.BaseAddress = new Uri("https://localhost:7251/api/");


                    var response = client.DeleteAsync("Examen/" + idExamen).Result;

                    if (response.IsSuccessStatusCode)
                    {
                        result = true;

                    }
                    else
                    {
                        result = false;
                    }
                }
                catch (WebException webex)
                {

                }
                finally
                {

                }
            }
            return result;
        }

        public DataTable ConsultarExamen(string Nombre, string Descripcion, bool dbinstance)
        {
            if (!isValidstring(Nombre))
            {
                Resultado = "Validar Valor Nombre, ";
                return null;
            }
            if (!isValidstring(Descripcion))
            {
                Resultado = "Validar Valor Descrpcion.";
                return null;
            }
            bool result = false;
            DataTable dt = new DataTable();
            if (dbinstance)
            {
                try
                {

                    getConnection();
                    comm = new SqlCommand("spConsultar", conn);
                    comm.CommandType = CommandType.StoredProcedure;
                    comm.Parameters.Add("@Nombre", SqlDbType.Int).Value = Nombre;
                    comm.Parameters.Add("@Descripcion", SqlDbType.Int).Value = Descripcion;
                    conn.Open();
                    SqlDataReader dr = comm.ExecuteReader();
                    dt.Load(dr);
                    dr.Close();
                    conn.Close();
                    Resultado = "Se ejecuto con exito";
                    return dt;

                }
                catch (SqlException sqex)
                {
                    Resultado = sqex.InnerException.ToString();
                    return dt;
                }
                finally
                {
                    conn.Close();
                }
            }
            else
            {
                try
                {
                    var Exam = new Examen
                    {
                        //idExamen = idExamen,
                        Nombre = Nombre,
                        Descripcion = Descripcion
                    };
                    var client = new HttpClient();
                    client.BaseAddress = new Uri("https://localhost:7251/api/");


                    HttpResponseMessage response = client.GetAsync("Examen").Result;
                    string res = response.Content.ReadAsStringAsync().GetAwaiter().GetResult();
                    JsonConvert.DeserializeObject<Examen>(res);

                    if (response.IsSuccessStatusCode)
                    {
                        result = true;

                    }
                    else
                    {
                        result = false;
                    }
                }
                catch (WebException webex)
                {

                }
                finally
                {

                }
            }
            return dt;

        }

        public bool isValidstring(string s)
        {
            bool isvalid = true;
            if (s != null)
                if (s.Length > 0)
                {
                    Match m = Regex.Match(s, @"[ A-Za-zäÄëËïÏöÖüÜáéíóúáéíóúÁÉÍÓÚÂÊÎÔÛâêîôûàèìòùÀÈÌÒÙ.-]+", RegexOptions.IgnoreCase);
                    if (!m.Success)
                    {
                        isvalid = false;
                    }
                }
            return isvalid;
        }

        public bool isValidsint(int value)
        {
            bool isvalid = true;
            if (!(value.GetType() == typeof(int))) 
            {
                isvalid = false;
            }    
            return isvalid;
        }
    }
}

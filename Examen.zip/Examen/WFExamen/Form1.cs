using System.Linq.Expressions;

namespace WFExamen
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        apiexamen.clsExamen exa = new apiexamen.clsExamen();

        private void btnInstance_Click(object sender, EventArgs e)
        {
            switch (cmbComando.SelectedItem)
            {
                case "AgregarExamen":
                    if (exa.AgregarExamen(txtIdExamen.Text, txtNombre.Text, txtDescripcion.Text, true))
                        MessageBox.Show("Exito", "Se insert� con exito");
                    else
                        MessageBox.Show("Validar campos", exa.Resultado);
                    break;
                case "ActualizarExamen":
                    if (exa.ActualizarExamen(txtIdExamen.Text, txtNombre.Text, txtDescripcion.Text, true))
                        MessageBox.Show("Exito", "Se Actualiz� con exito");
                    else
                        MessageBox.Show("Validar campos", exa.Resultado);
                    break;
                case "EliminarExamen":
                    if (exa.EliminarExamen(txtIdExamen.Text, true))
                        MessageBox.Show("Exito", "Se elimino con exito");
                    else
                        MessageBox.Show("Validar campos", exa.Resultado);
                    break;
                case "ConsultarExamen":
                    dgvExam.DataBind(exa.ConsultarExamen(txtNombre.Text, txtDescripcion.Text, true));
                    break;
                default:
                    dgvExam.DataBind(exa.ConsultarExamen(txtNombre.Text, txtDescripcion.Text, true));
                    break;
            }
        }

        private void btnServ_Click(object sender, EventArgs e)
        {
            switch (cmbComando.SelectedItem)
            {
                case "AgregarExamen":
                    if (exa.AgregarExamen(txtIdExamen.Text, txtNombre.Text, txtDescripcion.Text, false))
                        MessageBox.Show("Exito", "Se insert� con exito");
                    else
                        MessageBox.Show("Validar campos", exa.Resultado);
                    break;
                case "ActualizarExamen":
                    if (exa.ActualizarExamen(txtIdExamen.Text, txtNombre.Text, txtDescripcion.Text, false))
                        MessageBox.Show("Exito", "Se Actualiz� con exito");
                    else
                        MessageBox.Show("Validar campos", exa.Resultado);
                    break;
                case "EliminarExamen":
                    if(exa.EliminarExamen(txtIdExamen.Text, false))
                    MessageBox.Show("Exito", "Se elimino con exito");
                    else
                        MessageBox.Show("Validar campos", exa.Resultado);
                    break;
                case "ConsultarExamen":
                    dgvExam.DataBind(exa.ConsultarExamen(txtNombre.Text, txtDescripcion.Text, false));
                    break;
                default:
                    dgvExam.DataBind(exa.ConsultarExamen(txtNombre.Text, txtDescripcion.Text, false));
                    break;
            }
        }
    }
}
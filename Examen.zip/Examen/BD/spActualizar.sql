Create procedure spActualizar
@id int, 
@Nombre varchar(255), 
@Descripcion varchar(255)
as 
 update tblExamen set Nombre = @Nombre , Descripcion = @Descripcion where idExamen = @id
GO 
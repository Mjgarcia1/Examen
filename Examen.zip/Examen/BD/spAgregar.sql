Create procedure spAgregar 
@id int, 
@Nombre varchar(255), 
@Descripcion varchar(255)
AS 
 insert into tblExamen values(@id, @Nombre , @Descripcion)
GO
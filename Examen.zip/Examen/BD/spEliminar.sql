Create procedure spEliminar 
@id int 
as 
 delete tblExamen where idExamen = @id
GO 
Create database BdiExamen;
Use BdiExamen;
create table tblExamen(idExamen int not null , Nombre Varchar(255), Descripcion varchar(255), primary key(idExamen))
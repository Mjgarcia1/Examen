Create procedure spConsultar
@Nombre varchar(255), 
@Descripcion varchar(255)
as 
 select * from tblExamen where Nombre  like '%'+@Nombre+'%'  and Descripcion like '%'+@Descripcion+'%'
GO
﻿using Microsoft.EntityFrameworkCore;
using WsApiexamen.Models;

namespace WsApiexamen.Data
{
    public class DataContext : DbContext 
    {

        public DataContext (DbContextOptions<DataContext> options) : base(options) { }

        public DbSet<Examen> Examen { get; set; }
    }
}

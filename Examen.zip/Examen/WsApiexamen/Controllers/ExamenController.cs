﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using WsApiexamen.Models;

namespace WsApiexamen.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ExamenController : ControllerBase
    {

        private readonly DataContext dataContext;

        public ExamenController(DataContext dataContext) 
        {
            this.dataContext = dataContext;
        }
        
        //Obtiene todos los registros de examen de la bd
        [HttpGet]
        public async Task<ActionResult<List<Examen>>> get()
        {

            return Ok(await this.dataContext.Examen.ToListAsync());
        }

        //Obtiene examen por Id
        [HttpGet("{Id}")]
        public async Task<ActionResult<Examen>> ConsultarExamen(int Id)
        {
            var examen = await this.dataContext.Examen.FindAsync(Id);
            if (examen == null)
                return BadRequest("No hay información relacionada al Id");
            return Ok(examen);
        }

        //Crea un registro de examen en bd
        [HttpPost]
        public async Task<ActionResult<List<Examen>>> AgregarExamen(Examen examen)
        {
            this.dataContext.Examen.Add(examen);
            //Validamos si los cambios se registran
            if(await dataContext.SaveChangesAsync() > 0)
                return Ok(await this.dataContext.Examen.ToListAsync());
            else
                return BadRequest("No se creo el registro");
        }

        //Actualiza un registro de examen por Id
        [HttpPut]
        public async Task<ActionResult<List<Examen>>> ActualizarExamen(Examen examen)
        {
            var exam = await this.dataContext.Examen.FindAsync(examen.idExamen);
            if (exam == null)
                return BadRequest("No hay información relacionada al Id");
            exam.Descripcion = examen.Descripcion;
            exam.Nombre = examen.Nombre;
            if (await dataContext.SaveChangesAsync() > 0)
                return Ok(await this.dataContext.Examen.ToListAsync());
            else
                return BadRequest("No se actualizo el registro");
        }

        //Elimina un registro de examen si existe
        [HttpDelete("{Id}")]
        public async Task<ActionResult<List<Examen>>> EliminarExamen(int Id)
        {
            var examen = await this.dataContext.Examen.FindAsync(Id);
            if (examen == null)
                return BadRequest("No hay información relacionada al Id");
            this.dataContext.Examen.Remove(examen);
            if (await dataContext.SaveChangesAsync() > 0)
                return Ok(await this.dataContext.Examen.ToListAsync());
            else
                return BadRequest("No se elimino el registro");
        }
    }
}
